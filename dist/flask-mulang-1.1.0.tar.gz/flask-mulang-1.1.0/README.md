# Flask Mulang (Flask multilanguage)

This package has the basic needs to help you make your website multilingual, 
in Flask ofcourse.

This readme file will soon be complete to document **flask-mulang**.

This flask extension is inspired by [**Babel**](https://pypi.org/project/Babel/)
which is an advanced application-internationalizing python package, 
but works on `.ini` files or what is knows as **config files**